#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "date.h"

int
main(int argc, char *argv[]){

  print_count();
  exit();
}
